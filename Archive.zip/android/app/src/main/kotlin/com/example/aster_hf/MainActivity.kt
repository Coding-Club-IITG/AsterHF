package com.example.aster_hf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
